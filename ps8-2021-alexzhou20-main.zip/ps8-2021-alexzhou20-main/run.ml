(*
                          CS 51 Problem Set
                 Simulation of an Infectious Disease

                        Running the simulation
 *)

let _ = Config.cVISUALIZE := true;
        Simulation.run () ;;
